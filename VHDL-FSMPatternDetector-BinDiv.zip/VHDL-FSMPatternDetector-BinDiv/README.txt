-----------------------------------------------------------------------------------------------
For Question #1,
Please make sure to zoom in once or twice. Dr. Zheng informed us in class that the number of detections for the given sequence is 8. I indeed got the correct output (the # of detections: 8).
-----------------------------------------------------------------------------------------------
For Question #2,
If you change the radix to decimal, I indeed have the right output as per the problem description. 'corr_t' pulls up when the exp_quo = outp_quo, and exp_rmd = outp_rmd. I used one test because it one that isn't the "easy case".

(Communication between master and slave)
----------------------------------------
-- Sent from Master to Slave
dvsr = 197
dvnd = 10

-- Master holds the answer of...
exp_quo: 19
exp_rmd: 7

-- Sent from Slave to Mater (after doing calculation given in Chu's Book)
outp_quo: 19
outp_rmd: 7

Since exp_quo = outp_quo, and exp_rmd = outp_rmd, the corr_t goes HIGH in the simulation, which is correct.

** NOTE: we also have fin_t which lets goes HIGH when data is finished sending.... **
-----------------------------------------------------------------------------------------------
