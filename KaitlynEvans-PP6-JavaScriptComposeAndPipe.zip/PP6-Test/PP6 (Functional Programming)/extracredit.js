/*
***********************************************************************************************
Name: Kaitlyn Evans
U23768207
Professor Oropallo
Data Structures, COP4530
Due: April 23rd, 2019

The extra credit program takes one command line argument, that will be converted to a number
between 0 and 19, representing which image from the dogs.json JSON file to print to the
terminal. If an invalid number (outside 0 to 19 or just not a number) or has no value, you can
assume the image to print is at image 0.
***********************************************************************************************
*/

/*
****************************************************************************************************
POA: piping and composing everything to get familiar with both methods just like in the app.js file!

"going down the pipe: 1,2,3"
"compose yourself in: 3,2,1"
****************************************************************************************************
*/

// required because using ramda
const R = require('ramda');

// the hint via EC: to use these libs
const GOT = require('got');
const termImg = require('terminal-image');

// used to retrieve the dogs.JSON file
const FS = require('fs');

// takes one command line argument
// working
let args = process.argv.slice(2);

// working
/*const streamIn = R.compose (
    R.prop('items')
);*/

// working
const streamIn = R.pipe (
    R.prop('items')
);

/*
**********************************************************************************************
the hint via EC: use Ramda and JS to create
functions that can access the nth link for an image using that command line argument (use the
“m” property of “media” for the image link) from the Flickr data
**********************************************************************************************
*/

// working
/*const getImage = R.compose (
    R.map(R.prop('media')),
    streamIn,
);*/

// working
const getImage = R.pipe (
    streamIn,
    R.map(R.prop('media'))
);

// working
/*const getImageLink = R.compose (
    R.map(R.prop('m')),
    getImage,
);*/

// working
const getImageLink = R.pipe (
    getImage,
    R.map(R.prop('m'))
);

// retrieves the dog.JSON file
// working
const flickrDataDogFileExtraCredit = JSON.parse(FS.readFileSync('dogs.json', 'utf8'));

// command line argument that is converted to a number 0 to 19,
// representing which image from the dogs.json JSON file to print to the terminal
// working
// pure
parseThisFile = (x) => {
    y = getImageLink(x);
    //  If an invalid number (outside 0 to 19 or just not a number) or has no value, you can 
    // assume the image to print is at image 0.
    // working
    // impure; manual controlling the flow
    if(args < 0 || args > 19) {
        args = 0;
    }
    // not working
    /*else {
        continue;
    }*/

    // straight from github example provided via the PP6.pdf
    // working
    (async () => {
        const {body} = await GOT(y[args], {encoding: null});
        console.log(await termImg.buffer(body));
    })();

};

// calling the parsing function on the flickr data extra credit file: dogs.JSON
// working
parseThisFile(flickrDataDogFileExtraCredit);