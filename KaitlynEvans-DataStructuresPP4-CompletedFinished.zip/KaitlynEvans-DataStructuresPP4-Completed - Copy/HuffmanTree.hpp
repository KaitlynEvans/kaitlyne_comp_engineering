#ifndef HUFFMANTREE_H
#define HUFFMANTREE_H

#include "HuffmanBase.hpp"
#include "Map.hpp"
#include <unordered_map>
#include <map>
#include <vector>
#include <sstream>

class HuffmanTree : public HuffmanTreeBase
{
  public:
    HuffmanTree(){
        // create HuffmanTree

    };
    ~HuffmanTree(){

    };

    virtual std::string compress(const std::string inputStr) override;
    virtual std::string serializeTree() const override;
    virtual std::string decompress(const std::string inputCode, const std::string serializedTree) override;

    // working
    void preOrder(HuffmanNode *hn, std::string codestr, std::map<char, std::string> &hnm) const
    {
        // visit the root
        // traverse through the left subtree,
        // then travers through the right subtree

        if (hn->isLeaf())
        {
            // std::cout << "huffmanNode is a leaf." << std::endl;
            // working
            hnm[hn->getCharacter()] = codestr;
            /*for(auto pair : hnm) {
                std::cout << pair.first << ": " << pair.second << std::endl;
                }*/
        }
        else
        {
            // std::cout << "huffmanNode is NOT a leaf" << std::endl;
            // working
            preOrder(hn->left, codestr + "0", hnm);
            preOrder(hn->right, codestr + "1", hnm);
        }
    };

    void postOrder(HuffmanNode *hn)
    {
        // traverse through the left subtree,
        //      -- call recursive function on left and right
        // traverse through the right subtree,
        //      -- call recursive function on left and right
        // then visit the root.

        // Tree serialization will organize the characters associated with the nodes using post order.
        // During the post order when you visit a node,
        /* if it the node is a leaf (external node) then you add a L plus the character to the
        serialize tree string */
        // if it is a branch (internal node) then you add a B to the serialize tree string

        if(hn != nullptr) {
            postOrder(hn->left);
            postOrder(hn->right);
            
            if(hn->isLeaf()) {
                huffSerialString += "L";
                huffSerialString += hn->getCharacter();    
            }

            if(hn->isBranch()) {
                huffSerialString += "B";
            }
        }
        // std::cout << "serialStr, PostOrder: " << huffSerialString << std::endl;
    };

    void clearTree(HuffmanNode* hn) {
        if(hn != nullptr) {
            clearTree(hn->left);
            clearTree(hn->right);
            delete hn;
        }    
    };

  private:
    std::string inStr;
    std::string huffCodeString;
    std::string huffSerialString;
    std::string compressInput;
    std::map<char, std::string> huffCodeMap;
    std::string decompressString;
};

#endif