#ifndef GRAPH_H
#define GRAPH_H

#include "GraphBase.hpp"
#include "Edge.hpp"
#include <iostream>
#include <string>
#include <map>
#define INF 10000

class Graph : public GraphBase {
public:
    Graph() {

    };
    ~Graph() {
        // working
        graphComps.erase(graphComps.begin(), graphComps.end());
        // working - this should be an error, just checking to make sure the 
        // destructor is working perfectly! AND it is!
        // std::cout << graphComps.at(0) << std::endl;
    };
    void addVertex(std::string label);
    void removeVertex(std::string label);
    void addEdge(std::string label1, std::string label2, unsigned long weight);
    void removeEdge(std::string label1, std::string label2);
    unsigned long shortestPath(std::string startLabel, std::string endLabel, std::vector<std::string> &path);
    void printShortestPath(std::map<std::string, std::string> startLabel, std::string endLabel, std::vector<std::string> &path);

private:
    friend class Edge;
    std::vector<std::string> verticesVec;
    std::vector<Edge*> graphComps;
};

#endif