/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Kaitlyn Evans/Desktop/CDA 4203 - CSD Lab/tutorial_2/subtractor4.v";



static void Always_35_0(char *t0)
{
    char t4[8];
    char t18[8];
    char t20[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t19;

LAB0:    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 3008);
    *((int *)t2) = 1;
    t3 = (t0 + 2720);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(36, ng0);

LAB5:    xsi_set_current_line(37, ng0);
    t5 = (t0 + 1208U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t4 + 4);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (~(t8));
    *((unsigned int *)t4) = t9;
    *((unsigned int *)t5) = 0;
    if (*((unsigned int *)t7) != 0)
        goto LAB7;

LAB6:    t14 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t14 & 15U);
    t15 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t15 & 15U);
    t16 = (t0 + 1048U);
    t17 = *((char **)t16);
    memset(t18, 0, 8);
    xsi_vlog_unsigned_add(t18, 4, t4, 4, t17, 4);
    t16 = (t0 + 1368U);
    t19 = *((char **)t16);
    memset(t20, 0, 8);
    xsi_vlog_unsigned_add(t20, 4, t18, 4, t19, 1);
    t16 = (t0 + 1768);
    xsi_vlogvar_assign_value(t16, t20, 0, 0, 4);
    goto LAB2;

LAB7:    t10 = *((unsigned int *)t4);
    t11 = *((unsigned int *)t7);
    *((unsigned int *)t4) = (t10 | t11);
    t12 = *((unsigned int *)t5);
    t13 = *((unsigned int *)t7);
    *((unsigned int *)t5) = (t12 | t13);
    goto LAB6;

}


extern void work_m_00000000002602218886_4087910229_init()
{
	static char *pe[] = {(void *)Always_35_0};
	xsi_register_didat("work_m_00000000002602218886_4087910229", "isim/subtractor4_testbench_isim_beh.exe.sim/work/m_00000000002602218886_4087910229.didat");
	xsi_register_executes(pe);
}
