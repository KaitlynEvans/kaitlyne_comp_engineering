/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000003632838476_0327875659_init();
    work_m_00000000002602218886_3544349229_init();
    work_m_00000000002602218886_4087910229_init();
    work_m_00000000001103776583_1192050501_init();
    work_m_00000000001398314200_2091510897_init();
    work_m_00000000002986298341_3353550948_init();
    work_m_00000000003587148777_1933267095_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000003587148777_1933267095");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
