README:
-------------------------------------------------------------------------------
For Q1,
My behavioral verilog code is the module called, 'mydesign_beh' and the corresponding testbench is called 'mydesign_beh_testbench'.
-------------------------------------------------------------------------------
For Q2,
My behavioral verilog code includes the following components:
	--> fulladder4
	--> subtractor4
	--> inverter_primitive (Updated file from the tutorial)
	--> multiplier4

The additional included modules are the following:
	--> mux_21_beh
	--> mydesign_str
-------------------------------------------------------------------------------

** I don't know how to organize/seperate these files in ISE, but I think my explanation above makes the organization of files very clear.

I have both behavioral and structural files for my design called:
	--> mydesign_beh
	--> mydesign_str