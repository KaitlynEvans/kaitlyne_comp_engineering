/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000000510473288_1260470467_init();
    work_m_00000000003831024245_2199507181_init();
    work_m_00000000002712152874_3911238833_init();
    work_m_00000000004223782694_0285162525_init();
    work_m_00000000003833105633_4265375256_init();
    work_m_00000000001643782312_1399908676_init();
    work_m_00000000000321375991_0921686212_init();
    work_m_00000000002785034857_0968752412_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002785034857_0968752412");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
