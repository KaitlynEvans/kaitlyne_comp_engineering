#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "equipment.h"
#include "readline.h"

struct equipment *append_to_list(struct equipment *list)
{
 struct equipment *new_node;
 new_node = malloc(sizeof(struct equipment));

 if(new_node == NULL)
 {
  printf("malloc failed.\n");
 } 

 struct equipment *last;
 struct equipment *ptr; // pointer that will be used to point to list

 int flag; // flag will be used to flag whether equipment exists or not
 flag = 0; // 0: equipment does not exist, if doesn't exist then ask for
           // quantity, and add to list
           // 1: equipment does exist, if so then print message and exit

 printf("Enter a type: "); // asking for user input
 read_line(new_node->type, NAME_LEN +1); // read-in user input via read_line() function

 printf("Enter a description: "); // asking for user input
 read_line(new_node->description, NAME_LEN +1); // read-in user input via read_line() function

 for(ptr = list; ptr != NULL; ptr = ptr->next)
 {
   if((strcmp(ptr->type, new_node->type) == 0) && (strcmp(ptr->description, new_node->description) == 0))
   {
    printf("The equipment already exists.\n");
    flag = 1;
    return ptr;
   }
 }

 if(flag == 0)
 {
  printf("Enter an equipment quantity: ");
  scanf("%d", &new_node->quantity);
 }
  
 last = new_node;
 last->next = NULL;

 if(list == NULL)
 {
  list = last;
  return list;
 }
 
 // ptr: is the current
 // prev: is the previous
 struct equipment *prev;
 for(ptr = list, prev = NULL; ptr != NULL && (strcmp(ptr->type, new_node->type) < 0);
                                                         prev = ptr, ptr = ptr->next);

 int flag_description;
 flag_description = 0;
 for(; ptr != NULL && (strcmp(ptr->description, new_node->description) < 0 &&
						    strcmp(ptr->type, new_node->type) == 0);
                                                    prev = ptr, ptr = ptr->next);
 new_node->next = ptr;
 if(prev == NULL)
 {
  return new_node;
 }
 else if(prev != NULL)
 {
   prev->next = new_node;
   return list;
 }
 
 printf("reach the end of the append_to_list().\n");
 return NULL;
}

void update(struct equipment *list)
{
  struct equipment *up_info;
  up_info = malloc(sizeof(struct equipment));

  int flag; // flag will be used to check whether or not equipment exists
  flag = 0; // 0: equipment does not exist, print message
            // 1: equipment does exist, therefore update quantity by
            // adding local variable to existing quantity

  printf("Enter the equipment's type: ");
  read_line(up_info->type, NAME_LEN +1);

  printf("Enter the equipment's description: ");
  read_line(up_info->description, NAME_LEN +1);

  int quantity;
  quantity = 0;

  printf("Enter the quantity to be updated: ");
  scanf("%d", &quantity);

  struct equipment *p;
  for(p = list; p != NULL; p = p->next)
  {
   if((strcmp(p->type, up_info->type) == 0) && (strcmp(p->description, up_info->description) == 0))
   {
    p->quantity = (quantity + p->quantity);
    printf("%s\t %s\t updated to: %d\t\n", p->type, p->description, p->quantity);
    flag = 1;
    // return p;
   }
  }
  
  if(flag == 0)
  {
      printf("Equipment not found.\n");
  }
}

void printList(struct equipment *list)
{
  struct equipment *p;
  printf("=====================================================\n");
  printf("Equipment:\tDescription:\tQuantity:\n");
  for(p = list; p != NULL; p = p->next)
  {
   printf("%s\t%s\t%d\n", p->type, p->description, p->quantity);
  }
  printf("=====================================================\n");
}

void clearList(struct equipment *list)
{

 struct equipment *p;
 while(list != NULL)
 {
  p = list;
  list = list->next;
  if(p != NULL)
  {
   free(p);
  }
 }
 
 printf("The list has been cleared.\n");

}

struct equipment *delete_from_list(struct equipment *list)
{
 struct equipment *new_node;
 new_node = malloc(sizeof(struct equipment));

 int flag;
 flag = 0; // if flag is zero: equipment doesn't exist to delete
           // if flag is one: equipment does exist, and delete node

 if(new_node == NULL)
 {
  printf("malloc failed.\n");
 }

 printf("Type to delete: ");
 read_line(new_node->type, NAME_LEN +1);

 printf("Description to delete: ");
 read_line(new_node->description, NAME_LEN +1);

 struct equipment *p; //  curr == p
 struct equipment *q; // prev == q

 for(p = list, q = NULL; p != NULL; q = p, p = p->next)
 {
  if((strcmp(p->type, new_node->type) == 0) && (strcmp(p->description, new_node->description)) == 0)
  {
   flag = 1; // the equipment was found
   printf("This equipment exists.\nDeleted: %s %s\n", new_node->type, new_node->description);
   break;
  }
 }

 if(flag == 0)
 {
  printf("This equipment doesn't exist.\n"); // if equipment isn't found, print message
  return list; // return list
 }

 if(p == NULL)
 {
  return list;
 }
 if(q == NULL)
 {
  list = list->next;
 }
 else
 {
  q->next = p->next;
 }
 free(p);
 return list; 

  printf("Reaching the end of delete_from_list().\n");
  return NULL;
}
