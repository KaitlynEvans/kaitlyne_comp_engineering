/*
****************************
Name: Kaitlyn Evans
Project 9: Group Equipment
****************************
*/
/**********************************************************
 * main: Prompts the user to enter an operation code,     *
 *       then calls a function to perform the requested   *
 *       action. Repeats until the user enters the        *
 *       command 'q'. Prints an error message if the user *
 *       enters an illegal code.                          *
 **********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "readline.h"
#include "equipment.h"

int main(void)
{
  char code;

  struct equipment *e_list = NULL;  
  printf("Operation Code: a for appending to the list, u for updating an equipment"
	  ", p for printing the list; q for quit.\n");
  for (;;) {
    printf("Enter operation code: ");
    scanf(" %c", &code);
    while (getchar() != '\n')   /* skips to end of line */
      ;
    switch (code) {
      case 'a': e_list = append_to_list(e_list);
                break;
      case 'u': update(e_list);
                break;
      case 'p': printList(e_list);
                break;
      case 'd': e_list = delete_from_list(e_list);
                break;
      case 'q': clearList(e_list);
		return 0;
      default:  printf("Illegal code.\n");
    }
    printf("\n");
  }
}
