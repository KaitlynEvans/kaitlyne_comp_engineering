#include <iostream>
#include <string>
#include <fstream>
#include "storytokenizer.h"

using namespace std;

int main() {
	string line, story;

	//getline(cin, line); // gets the first line
	//while (cin && line != "</html>"){ // read in whole story until end html tag
	//	story += line + '\n';
	//	getline(cin, line); 
	//}

	ifstream file("test-example.html");

	if (file.is_open()) {

		getline(file, line);
		while (line != "</html>") { // read in whole story until end html tag
			story += line + '\n';
			getline(file, line);
		}
	}

	StoryTokenizer st(story);
	int pass = 0; // number of passages
	while (st.hasNextPassage()) { // if the whole story exists,
		PassageToken ptok = st.nextPassage();
		pass++; // increment number of passages
		cout << "Passage " << pass << ":  " << endl;
		cout << ptok.getText() << endl; // if story tokenized into pass, print.
		PassageTokenizer pt(ptok.getText());
		while (pt.hasNextSection()) {
			SectionToken stok = pt.nextSection();
			switch (stok.getType()) {
			case LINK:
				cout << "  Link:  ";
				break;
			case SET:
				cout << "  Set:  ";
				break;
			case GOTO:
				cout << "  Go-to:  ";
				break;
			case IF:
				cout << "  If:  ";
				break;
			case ELSEIF:
				cout << "  Else-if:  ";
				break;
			case ELSE:
				cout << "  Else:  ";
				break;
			case BLOCK:
				cout << "  Block:  ";
				break;
			case TEXT:
				cout << "  Text:  ";
				break;
			default:
				cout << "  Unknown token:  ";
			}
			cout << stok.getText() << endl;
		}
	}
	cout << "The story has been read." << endl;
	system("pause");

	return 0;

}
