#include "storytokenizer.h"
using namespace std;

bool StoryTokenizer::hasNextPassage() { // finished
	if (passVec.size() < 0) {
		return false;
	}
	return true;
}

PassageToken StoryTokenizer::nextPassage() { // finished
	if (hasNextPassage()) {
		PassageToken ptoken(passVec.at(0));
		passVec.erase(passVec.begin());
		return ptoken;
	}
	else {
		PassageToken ptoken("");
		return ptoken;
	}
}

bool PassageTokenizer::hasNextSection() { // finished
	if (secVec.size() < 0) {
		return false;
	}
	return true;

}

SectionToken PassageTokenizer::nextSection() { // add more content
	if (hasNextSection()) {
		SectionToken stoken(secVec.at(0));
		secVec.erase(secVec.begin());
		return stoken;
	}
	else {
		SectionToken stoken("");
		return stoken;
	}
}
