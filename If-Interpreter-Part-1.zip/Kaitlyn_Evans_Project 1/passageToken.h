#ifndef __passagetoken_h
#define __passagetoken_h

#include <string>
using namespace std;

class PassageToken{ // finished
	private:
		string s;
	public:
		PassageToken(string strng){ // finished
			// s = str;
			if (strng.empty()) {
				s = strng;
			}
			else {
				unsigned firstInst = strng.find_first_of('>');
				unsigned updatedfirstInst = strng.find_first_of('>') + 1;
				string passText;
				passText = "\n" + strng.substr(firstInst, updatedfirstInst) + "\n";
				s = passText;
			}
		}
		~PassageToken(){

		}
		string getText() const{ // finished
			return s;
		}
};

#endif