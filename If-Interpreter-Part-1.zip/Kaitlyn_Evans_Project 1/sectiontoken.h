#ifndef __sectiontoken_h
#define __sectiontoken_h

#include <string>
using namespace std;
enum tok_t {LINK, GOTO, IF, ELSEIF, ELSE, SET, BLOCK, TEXT};

class SectionToken{ // finished
	private:
		string s;
		tok_t sectoken;
	public:
		SectionToken(string strng) {
			s = strng;
		}
		~SectionToken() {

		}
		string getText() const { // finished
			return s;
		}
		tok_t getType() const { // finished
			return sectoken;
		}
};

#endif