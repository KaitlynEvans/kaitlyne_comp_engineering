/*
**********************************************
Name: Kaitlyn Evans
Project 11: This program will read the data
from a file, and sort the protein by average
customer review. The file that will be read
contains: the list of the top 5 recommend 
powders. The ouput file will have extension
.rcd.
**********************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NAME_LEN 99
#define PWDR_NUM 100

/*
******************************
Creating the structure, how to 
describe the objects in which make up
the object called protein.
******************************
*/

struct protein
{
	int inStock;
	int unitsSold;
	int numRev;
	float avgCustRev;
	char brand[NAME_LEN +1];
};


void selection_sort(struct protein protein_powder[], int n);
int string_compare(const void *p, const void *q);
int main(int argc, char *argv[])
{
	struct protein protein_powders[PWDR_NUM]; // creating the array to store the structs scanned in from file
	FILE *rpfile; // file pointer, read file pointer
	
	while(argc != 2) // if the arc 2 position is not empty and/or missing then open the file
	{
		printf("opening file... \n");
		rpfile = fopen(argv[2], "r"); // opening the read file		

	}

	if((rpfile = fopen(argv[1], "r")) ==  NULL)
	{
		printf("error in opening file, cannnot open...\n");
	}


	char o_name[NAME_LEN +1]; // creating char array to store the output name
	FILE *wpfile; // file pointer, write file pointer
	strcpy(o_name, argv[1]); // copy the input file name
	strcat(o_name, ".rcd"); // add the extension
	wpfile = fopen(o_name, "w"); // the wpfile name is now the input plus the extension
	printf("output file name: %s\n", o_name);	

	int i;
	i = 0;
	while(!feof(rpfile) && !ferror(rpfile)) // while the read pointer is not pointing to the EOF, nor 
						// find any error, then proceed scanning in file given
	{
		fscanf(rpfile, "%d\t %d\t %3f\t %d\t %[^\n]\n", &protein_powders[i].inStock, &protein_powders[i].unitsSold, 
											     &protein_powders[i].avgCustRev,
											     &protein_powders[i].numRev, 
											     protein_powders[i].brand);
		// printf("inStock: %d\t unitsSold: %d\t avgCustRev: %3f\t numRev: %d\t brand: %s\n", protein_powders[i].inStock,
		// 										   protein_powders[i].unitsSold,
		//										   protein_powders[i].avgCustRev, 
		//										   protein_powders[i].numRev,
		//										   protein_powders[i].brand);
		i++; 
	}

	// printf("The line count is: %d\n", i);
	// selection_sort(protein_powders, i); // calling the sort function);
	qsort(protein_powders, i, sizeof(struct protein), string_compare);

	/*
	***********************************************
	The following function was created to ensure
	that the selection sort was indeed in ascending
	order.
	***********************************************
	int j;
	for(j = 0; j < i; j++)
	{
		printf("inStock: %d\t unitsSold: %d\t avgCustRev: %-3f\t numRev: %d\t brand: %s\n", protein_powders[j].inStock,
 		  										   protein_powders[j].unitsSold,
									        	           protein_powders[j].avgCustRev,
						   					           protein_powders[j].numRev, 
												   protein_powders[j].brand);
	}

	**********************************************
	The following loop will print out the top five
	with the restrictions given via the assignment
	if the conditions are true, then print to the 
	newly created write file: protein.txt.rcd
	**********************************************
	*/

	int k;
	for(k = 0; k < (i -4); k++)
	{
		if(protein_powders[k].numRev >=50 && protein_powders[k].inStock != 0)
		{
			printf("%d\t %d\t %3f\t %d\t %s\n", protein_powders[k].inStock,
							    protein_powders[k].unitsSold,
							    protein_powders[k].avgCustRev,
							    protein_powders[k].numRev,
							    protein_powders[k].brand);
			fprintf(wpfile, "%d\t %d\t %3f\t %d\t %s\n", 
							    protein_powders[k].inStock,
							    protein_powders[k].unitsSold,
							    protein_powders[k].avgCustRev,
							    protein_powders[k].numRev,
							    protein_powders[k].brand);
		}

	}

	fclose(wpfile); // closing the write file pointer
	fclose(rpfile); // closing the read file pointer
	return 0;
}


int string_compare(const void *p, const void *q)
{
	const struct protein *p1  = p;
	const struct protein *p2 = q;

	if(p1->avgCustRev > p2->avgCustRev)
	{
		return -1;
	}
	else if(p1->avgCustRev == p2->avgCustRev)
	{
		return 0;
	}
	else
		return 1;
}

void selection_sort(struct protein protein_powders[], int n)
{
	int i;
	int j;
	struct protein temp;

	if(n == 1)
	{
		return;
	}

	for(i = 0; i < n; i++)
	{
		for(j = i +1; j < n; j++)
		{
			if(protein_powders[i].avgCustRev < protein_powders[j].avgCustRev)
			{
				temp = protein_powders[i];
				protein_powders[i] = protein_powders[j];
				protein_powders[j] = temp;
			}
		}
	}
	
}
	
