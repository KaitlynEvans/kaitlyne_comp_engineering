#include "readerwriter.h"

void rwlock_init(rwlock_t *rw) { 
   rw->readers = 0; 
   rw->writers = 0;
   sem_init(&rw->mutex, 0, 1); 
   sem_init(&rw->writer, 0, 1);
   sem_init(&rw->reader, 0, 1);
} 

void rwlock_acquire_readlock(rwlock_t *rw) { 
   sem_wait(&rw->mutex); 
   // -----------------
   // critical section
   // -----------------
   sem_wait(&rw->writer);
   if(rw->readers == 1)
	   rw->readers++;
   sem_post(&rw->mutex);
   sem_post(&rw->writer);
} 

void rwlock_release_readlock(rwlock_t *rw) { 
   sem_wait(&rw->mutex);
   // -----------------
   // critical section
   // -----------------
   sem_wait(&rw->writer);
   if(rw->readers == 0)
	   rw->readers--;
   sem_post(&rw->mutex);
   sem_post(&rw->writer);
} 

void rwlock_acquire_writelock(rwlock_t *rw) { 
   sem_wait(&rw->mutex);
   // -----------------
   // critical section
   // -----------------
   sem_wait(&rw->writer);
   if(rw->writers == 1)
	   rw->writers++;
   sem_post(&rw->mutex);
   sem_post(&rw->writer);
} 

void rwlock_release_writelock(rwlock_t *rw) { 
   sem_wait(&rw->mutex);
   // -----------------
   // critical section
   // -----------------
   sem_wait(&rw->writer);
   if(rw->writers == 0)
	   rw->writers--;
   sem_post(&rw->mutex);
   sem_post(&rw->writer);
}
