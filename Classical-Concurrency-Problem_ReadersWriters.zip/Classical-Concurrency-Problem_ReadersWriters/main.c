#include "readerwriter.h"

int loops;
int value = 0;
rwlock_t lock; 
FILE* scenario_results_fp;

void *reader(void *args) {
    int i;
   for(i = 0; i < loops; i++) {
        rwlock_acquire_readlock(&lock);
        //fprintf(scenario_results_fp, "read:");
        fprintf(scenario_results_fp, "read: %d\n", value);
        //printf("read: %d\n", value);
        rwlock_release_readlock(&lock);
    }
    return NULL;
}

void *writer (void *args) {
    int i;
    for(i = 0; i < loops; i++){
        rwlock_acquire_writelock(&lock);
        value++;
        //fprintf(scenario_results_fp, "write:");
        fprintf(scenario_results_fp, "write: %d\n", value);
        //printf("write: %d\n", value);
        rwlock_release_writelock(&lock);
    }
    return NULL;
}

void evil_scheduler() {
    fprintf(scenario_results_fp, "EVIL SCHEDULER!\n");
    //printf("I am the evil scheduler, here to ruin everything!\n");
    int x = 0, T, i, j;
    T = rand() % 100;
    for(i = 0; i < T; i++)
        for(j = 0; j < T; j++)
            x = i*j;
}

int main(int argc, char *argv[]) {
    // assert(argc == 4)
    // int num_readers = atoi(argv[1]);
    // int num_writers = atoi(argv[2]);
    // loops = atoi(argv[3]);
    assert(argc == 2);
    loops = rand() % 100;
    //pthread_t pr[num_readers], pw[num_writers];
    rwlock_init(&lock);

    FILE *scenarios_fp;
    char *scenarios_test = argv[1];
    scenarios_fp = fopen(argv[1], "r");
    char c;
    int num_readers = 0;
    int num_writers = 0;

    if(scenarios_fp == NULL) {
        printf("\tUnable to open file: scenarios.txt...\n");
        return -1;
    }
    else {
        printf("File opened: scenarios.txt...\n");
        while(fscanf(scenarios_fp, "%c", &c) == 1) {
            printf("%c", c);
            if(c == 'R') {
                printf("\treader found!\n");
                num_readers++;
            }
            if(c == 'W') {
                printf("\twriter found!\n");
                num_writers++;
            }
        }
    }

    printf("num_readers: %d\n", num_readers);
    printf("num_writers: %d\n", num_writers);

    fclose(scenarios_fp);
    scenario_results_fp = fopen("results.txt", "w");

    pthread_t pr[num_readers], pw[num_writers];

    //printf("--------\n");
    //:printf("begin...\n");
    int i;
    for (i = 0; i < num_readers; i++) {
	pthread_create(&pr[i], NULL, reader, NULL);
        evil_scheduler();
    }
	
    for (i = 0; i < num_writers; i++) {
	pthread_create(&pw[i], NULL, writer, NULL);
        evil_scheduler();
    }

    for (i = 0; i < num_readers; i++) {
	pthread_join(pr[i], NULL);
        evil_scheduler();
    }
	
    for (i = 0; i < num_writers; i++) {
	pthread_join(pw[i], NULL);
        evil_scheduler();
    }

    printf("end: value %d\n", value);
    printf("--------\n");   
    fclose(scenario_results_fp); 
  
    return 0;
}
