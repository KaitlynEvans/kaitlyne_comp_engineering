#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <assert.h>
// #include "common_threads.h"
#include <stdio.h>
// ------------------------------------
// from little book of semaphores:
// .wait() is analagous to sem_wait()
// .signal() is analagous to sem_post()
// ------------------------------------

typedef struct _rwlock_t { 
   int writers;
   int readers;
   sem_t mutex;
   sem_t writer;
   sem_t reader;

} rwlock_t; 

void rwlock_init(rwlock_t *rw) { 
   rw->readers = 0; 
   rw->writers = 0;
   sem_init(&rw->mutex, 0, 1); 
   sem_init(&rw->writer, 0, 1);
   sem_init(&rw->reader, 0, 1);
} 

void rwlock_acquire_readlock(rwlock_t *rw) { 
   sem_wait(&rw->mutex); 
   // -----------------
   // critical section
   // -----------------
   sem_wait(&rw->writer);
   if(rw->readers == 1)
	   rw->readers++;
   sem_post(&rw->mutex);
   sem_post(&rw->writer);
} 

void rwlock_release_readlock(rwlock_t *rw) { 
   sem_wait(&rw->mutex);
   // -----------------
   // critical section
   // -----------------
   sem_wait(&rw->writer);
   if(rw->readers == 0)
	   rw->readers--;
   sem_post(&rw->mutex);
   sem_post(&rw->writer);
} 

void rwlock_acquire_writelock(rwlock_t *rw) { 
   sem_wait(&rw->mutex);
   // -----------------
   // critical section
   // -----------------
   sem_wait(&rw->writer);
   if(rw->writers == 1)
	   rw->writers++;
   sem_post(&rw->mutex);
   sem_post(&rw->writer);
} 

void rwlock_release_writelock(rwlock_t *rw) { 
   sem_wait(&rw->mutex);
   // -----------------
   // critical section
   // -----------------
   sem_wait(&rw->writer);
   if(rw->writers == 0)
	   rw->writers--;
   sem_post(&rw->mutex);
   sem_post(&rw->writer);
}

int loops;
int value = 0;
rwlock_t lock;

void *reader(void *arg) {
    int i;
    for (i = 0; i < loops; i++) {
		rwlock_acquire_readlock(&lock);
		printf("read: %d\n", value);
		rwlock_release_readlock(&lock);
    }
    return NULL;
}

void *writer(void *arg) {
    int i;
    for (i = 0; i < loops; i++) {
		rwlock_acquire_writelock(&lock);
		value++;
		printf("write: %d\n", value);
		rwlock_release_writelock(&lock);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    assert(argc == 4);
    int num_readers = atoi(argv[1]);
    int num_writers = atoi(argv[2]);
    loops = atoi(argv[3]);

    pthread_t pr[num_readers], pw[num_writers];

    rwlock_init(&lock);

	printf("--------\n");
    printf("begin...\n");

    int i;
    for (i = 0; i < num_readers; i++)
		pthread_create(&pr[i], NULL, reader, NULL);
	
    for (i = 0; i < num_writers; i++)
		pthread_create(&pw[i], NULL, writer, NULL);

    for (i = 0; i < num_readers; i++)
		pthread_join(pr[i], NULL);
	
    for (i = 0; i < num_writers; i++)
		pthread_join(pw[i], NULL);

    printf("end: value %d\n", value);
	printf("--------\n");

    return 0;
}