// old version
make
./lock <num_readers> <num_writers> <loops>

// new version
make
./lock scenarios.txt

NOTE : the results of the tests will be saved in file, 'results.txt'
in the current working directory
