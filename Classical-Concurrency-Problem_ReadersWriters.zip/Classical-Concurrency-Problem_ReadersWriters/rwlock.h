#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

#ifndef rwlock_h
#define rwlock_h

typedef struct rwlock_t {
	int writers;
	int readers;
	sem_t mutex;
	sem_t writer;
	sem_t reader;
} rwlock_t;

#endif
