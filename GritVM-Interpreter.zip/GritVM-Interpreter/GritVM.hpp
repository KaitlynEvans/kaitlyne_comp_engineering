#ifndef GRITVM_H
#define GRITVM_H

#include "GritVMBase.hpp"
#include <list>

class GritVM : public GritVMInterface {
    friend class GritVMNode;
    public:
        GritVM() {
            accumlator = 0;
            machineStatus = WAITING;

            // initalizing variables for the linked list implementation
            /* header = new GritVMNode;
            trailer = new GritVMNode;
            header->next = trailer;
            trailer->prev = header; */
        };
        // ~GritVM();
        virtual STATUS
        load(const std::string filename, const std::vector<long> &initialMemory) override;
        virtual STATUS              run() override;
        virtual std::vector<long>   getDataMem() override;
        virtual STATUS              reset() override;

        // functions for linked list implementation
        /*

        */

    protected:
    long accumlator;
    std::vector<long> dataMem;
    std::list<Instruction> instructionMem;
    std::list<Instruction>::iterator currInstruction;
    STATUS machineStatus;

    // private data members for linked list implementation
    /*
    GritVMNode *header;
    GritVMNode *trailer;
    GritVMNode gritNode;
    */
};

class GritAccumlator {
    public:
        GritAccumlator() {
            accumlator = 0;
        }
        ~GritAccumlator();
    protected:
        long accumlator;
        GritAccumlator* prev;
        GritAccumlator* next;
};

class DataMember {
    public:
        DataMember();
        ~DataMember();
        DataMember* getDataMem();
    protected:

};

class GritInstruction {
    public:
        GritInstruction() {
            machineStatus = WAITING;
        }
        ~GritInstruction();
    protected:
        STATUS machineStatus;
};

class InstructionIterator {
    public:
        InstructionIterator();
        ~InstructionIterator();
    protected:
        Instruction *currInstruction;
};

#endif