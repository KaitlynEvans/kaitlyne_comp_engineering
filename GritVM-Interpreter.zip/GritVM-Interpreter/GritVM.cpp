/*
******************************************
Name: Kaitlyn Evans
U23768207
Class: Data Structures
Professor: Dr. Oropallo
21st, Feb. 2019
******************************************
*/

/*
Your GritVM will read in a file of code written in this specific GVM language, run
the instructions, and be able to return the results held in the GritVM object’s memory. The
GritVM has two variables that contain its memory: a NodeList that contains the instructions and
a Vector that contains the data. There will also be a single variable called the accumulator. The
accumulator stores the results of various operations as an intermediate. The accumulator is an
implicit operand for all mathematical calculations.

You will be responsible for programming in the functionality of the following instructions in your
implementation of GritVM.
*/

#include <iostream>
#include <fstream> // std::ifstream
#include <string> // string::getline
#include "GritVM.hpp"
#include "GritVMBase.hpp"

/*
********************************************************************************************
This method loads the GVM program into the GritVM object and copies initialMemory into the
data memory. Returns the current machine status. Throws if file cannot be read.
********************************************************************************************
*/

STATUS GritVM::load(const std::string filename, const std::vector<long> &initialMemory) {
    std::ifstream ifs(filename);
    // std::ofstream osf("toh.gvm"); // for the toh extra credit....
    std::string line; // each line of the file...

    if(!ifs.is_open()) {
        // std::cout << "error, can't open file." << std::endl;
        throw std::runtime_error("error.");
    }

    if(ifs.is_open()) {
        // std::cout << "file opened." << std::endl;
        while(ifs) {
            getline(ifs, line);
            // print out the contents of the file...
            // std::cout << line << std::endl;
            if(line.empty() || line == "\r" || line[0] == '#') {
                continue;
            }
            Instruction instructionTest(GVMHelper::parseInstruction(line));
            if(instructionTest.operation != UNKNOWN_INSTRUCTION) {
                instructionMem.push_back(instructionTest);
                /*
                ******************************************************************* 
                add here adding to the Linked List, otherwise function is the same.
                *******************************************************************
                */
            }
        }
    }

    ifs.close();

    dataMem = initialMemory;

    if(instructionMem.size() == 0) {
        machineStatus = WAITING;
    }
    else {
        machineStatus = READY;
    }

    return machineStatus;
};

/*
******************************************************************************************
This method starts the evaluation of the instructions. Returns the current machine status.
******************************************************************************************
*/

STATUS GritVM::run() {
    std::vector<long>::iterator iterator;
    for(currInstruction = instructionMem.begin(); instructionMem.begin() != instructionMem.end() 
    && (machineStatus == READY); currInstruction++) {

        Instruction ci(*currInstruction);
        long val = ci.argument;
        long dataMemLength = dataMem.size();
        iterator = dataMem.begin();

        if(ci.operation == CHECKMEM) {
            /*
            Checks to make sure DM is of at least size
            Z. If not, switch status to ERRORED
            */
            if(dataMemLength < val) {
                machineStatus = ERRORED;
            }
        }
        else if(ci.operation == CLEAR) {
            // Set the accumulator to 0
            accumlator = 0;
        }
        else if(ci.operation == AT) {
            /*
            Sets the accumulator to the value at: DM[X]
            A = DM[X]
            */
            accumlator = dataMem.at(val);
        }
        else if(ci.operation == SET) {
            /*
            Sets the DM[X] to the value in the accumulator
            DM[X] = A
            */
            dataMem.at(val) = accumlator;
        }
        else if(ci.operation == INSERT) {
            /*
            Inserts in DM at location X the value in the accumulator
            */
            std::vector<long>::iterator temp;
            temp = dataMem.begin();
            dataMem.insert((temp +val), accumlator);
        }
        else if(ci.operation == ERASE) {
            /*
            Erases location X in the DM
            */
            std::vector<long>::iterator temp;
            temp = dataMem.begin();
            dataMem.erase(temp +val);
        }
        else if(ci.operation == ADDCONST) {
            /*
            Adds C to the accumulator value
            A = A + C
            */
            accumlator += val;
        }
        else if(ci.operation == SUBCONST) {
            /*
            Subtracts C to the accumulator value
            A = A - C
            */
            accumlator -= val;
        }
        else if(ci.operation == MULCONST) {
            /*
            Multiply C to the accumulator value
            A = A * C
            */
            accumlator *= val;
        }
        else if(ci.operation == DIVCONST) {
            /*
            Divides C from the accumulator value
            A = A / C
            */
            accumlator /= val;
        }
        else if(ci.operation == ADDMEM) {
            /*
            Adds DM[X] to the accumulator value
            A = A + DM[X]
            */
            accumlator += dataMem[val];
        }
        else if(ci.operation == SUBMEM) {
            /*
            Subtracts DM[X] from the accumulator
            A = A – DM[X]
            */
            accumlator -= dataMem[val];
        }
        else if(ci.operation == MULMEM) {
            /*
            Multiplies DM[X] to the accumulator value
            A = A * DM[X]
            */
            accumlator *= dataMem[val];
        }
        else if(ci.operation == DIVMEM) {
            /*
            Divides DM[X] from the accumulator value
            A = A / DM[X]
            */
            accumlator /= dataMem[val];
        }
        else if(ci.operation == JUMPREL) {
            /*
            Goes forward/back Y instructions from the
            current instruction (can be negative)
            */
            std::advance(currInstruction, val -1);
        }
        else if(ci.operation == JUMPZERO) {
            /*
            Goes forward/back Y instructions from the
            current instruction (can be negative) if
            accumulator is 0. Otherwise just move
            forward 1 from the current instruction.
            */
            if(accumlator == 0) {
                std::advance(currInstruction, val -1);
            }
        }
        else if(ci.operation == JUMPNZERO) {
            /*
            Goes forward/back Y instructions from the
            current instruction (can be negative) if
            accumulator is not 0. Otherwise just move
            forward 1 from the current instruction.
            */
            if(accumlator != 0) {
                std::advance(currInstruction, val -1);
            }
        }
        else if(ci.operation == NOOP) {
            /*
            Perform no operation. Counts as an
            instruction but does nothing.
            */
        }
        else if(ci.operation == HALT) {
            /*
            Stop the GritVM and switch status to HALTED
            */
            machineStatus = HALTED;
        }
        else if(ci.operation == OUTPUT) {
            /*
            Output accumulator to std::cout
            */
            std::cout << "Accumlator: " << accumlator << std::endl;
        }
    } // for loop closing bracket!


    if(machineStatus == WAITING) {
        return machineStatus;
    }
    else {
        machineStatus = HALTED;
    }

    return machineStatus;
};

/*
*************************************
Returns a copy of the current dataMem
*************************************
*/

std::vector<long> GritVM::getDataMem() {
    return dataMem;
};

/*
****************************************************************************************
Sets the accumulator to 0, clears the dataMem and instructMem, sets the machineStatus to
WAITING.
****************************************************************************************
*/

STATUS GritVM::reset() {
    accumlator = 0;
    dataMem.clear();
     machineStatus = WAITING;
     return machineStatus;
};