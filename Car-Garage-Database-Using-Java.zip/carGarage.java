/*
*************************************
Kaitlyn Evans 
COP2510
November 26th, 2017

"I did not cheat on this assignment."
*************************************
*/

/*
The constructor:
***************************************
This contains data and methods related 
to the make, model, and year of the car. 
***************************************
*/

public class carGarage
{
   // instant data for make, model, and year of car
   private String make;
   private String model;
   private int year;
   
   // add other instants (cars) to register
   private static int carcount = 0;
   
   // Methods below are public. 
   
   
   // This is the constructor: sets up car object with specified data.
   public carGarage(String make, String model, int year)
   {
      this.make = make;
      this.model = model;
      this.year = year;
      carcount++; // updates the number of car objects created
   }
   
   // Overloaded Constructor: Sets up the Car Object.
   public carGarage()
   {
      this.model = " ";
      this.make = " ";
      this.year = 0;
      carcount++; // updates the number of car objects created
   }
   
   // Model accessor
   public String getModel()
   {
      return model;
   }
   
   // Model mutator
   public void setModel(String modelUpdate)
   {
      model = modelUpdate;
   }
   
   // Make accessor
   public String getMake()
   {
      return make;
   }
   
   // Make mutator
   public void setMake(String makeUpdate)
   {
      make = makeUpdate;
   }
   
   // Year accessor
   public int getYear()
   {
      return year;
   }
   
   // Year mutator
   public void setYear(int yearUpdate)
   {
      year = yearUpdate;
   }
   
   // Returns a string representation of the car. 
   public String toString()
   {
      return "Car Make: " + make + "\t\tCar Model: "
             + model + "\t\tCar Year: " + year;
   }
   
   // Returns the number of instants created
   public static int getcarcount()
   {
      return carcount;
   }
}