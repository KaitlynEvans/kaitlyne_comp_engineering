/*
*************************************
Kaitlyn Evans 
COP2510
November 26th, 2017

"I did not cheat on this assignment."
*************************************
*/

/*
*************************************
This is the driver for the car garage.
************************************* 
*/
import java.util.Scanner;

public class carTest
{
   public static void main(String[] args)
   {
      // Welcome String
      System.out.println("Welcome to the Local Garage!");
      // Stating will print out the immediate information on Randy's car
      // This will print the contructor with the last car as blank
      System.out.println("Here are is the information we have" +
                         " Randy's cars in the garage: ");
                         
      carGarage c1 = new carGarage("Hyundai", "Elantra", 2013);
      carGarage c2 = new carGarage("Chevy","Malibu", 2013);
      carGarage c3 = new carGarage("-","-", 0); // Third car that needs updating
      carGarage c4 = new carGarage(); // Creates a new car object for narrative
      
      System.out.println(c1);
      System.out.println(c2);
      System.out.println(c3);
      
      // Calls the scanner function
      Scanner scan = new Scanner(System.in);
      
      // Prints to the screen that there is missing information
      System.out.println("Seems like we are missing information" +
                         " on one of the cars.");
      
      
      // Creates the storing of the information from the user 
      String carMake;
      String carModel;
      int carYear;
      
      // Asking for information from user, then stores it in the 
      // appropriate data types.
      System.out.println("Enter the car's model: ");
      carModel = scan.nextLine();
      System.out.println("Enter the car's make: ");
      carMake = scan.nextLine();
      System.out.println("Enter the car's year: ");
      carYear = scan.nextInt();
      
      // Take information above from user, and update the third car 
      // information.
      c3.setModel(carModel);
      c3.setMake(carMake);
      c3.setYear(carYear);
      
      // Print out the updated information
      System.out.println(c1);
      System.out.println(c2);
      System.out.println(c3);
      
      
      // Calling for a new scanner for the fourth car 
      Scanner input = new Scanner(System.in);
      
      
      // Prints out asking for more information to "complete"
      // the program.
      System.out.println("Please enter another set of data" +
                         " for Randy's cars: ");
      
      
      // new data types to store new information from user. 
      String NewcarMake;
      String NewcarModel;
      int NewcarYear;
      
      // Asking for input from the user, then stores new info 
      // for the fourth object.
      System.out.println("Enter the car's model: ");
      NewcarModel = input.nextLine();
      System.out.println("Enter the car's make: ");
      NewcarMake = input.nextLine();
      System.out.println("Enter the car's year: ");
      NewcarYear = input.nextInt();
      
      // Updates the 4th object in the register
      c4.setModel(NewcarModel);
      c4.setMake(NewcarMake);
      c4.setYear(NewcarYear);
      
      // Prints  out the final summary of the 
      // four car objects.
      System.out.println("Here is a final summary of" +
                         " Randy's cars: ");
      
      System.out.println(c1);
      System.out.println(c2);
      System.out.println(c3);
      System.out.println(c4); 
   }
}