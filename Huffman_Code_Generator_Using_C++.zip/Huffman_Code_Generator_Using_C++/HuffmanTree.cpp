#include "HuffmanBase.hpp"
#include "HuffmanTree.hpp"
#include "HeapQueue.hpp"

#include <map> // std::unordered_map
#include <stack> // std::stack, top(), pop()

/*
**************************************************************************************************
Compress the input string using the method explained above. Note: Typically we would be
returning a number of bits to represent the code, but for this project we are returning a string
**************************************************************************************************
A program can generate Huffman codes from a string using the following steps:
• Generate a list of the frequency in which characters appear in the string using a map
• Inserting the characters and their frequencies into a priority queue (sorted first by the lowest
frequency and then lexicographically)
• Until there is one element left in the priority queue
• Remove two characters/frequencies pairs from the priority queue
• Turn them into leaf nodes on a binary tree
• Create an intermediate node to be their parent using the sum of the frequencies for those
children
• Put that intermediate node back in the priority queue
• The last pair in the priority queue is the root node of the tree
• Using this new tree, encode the characters in the string using a map with their prefix code by
traversing the tree to find where the character’s leaf is. When traversal goes left, add a 0 to
the code, when it goes right, add a 1 to the code
• With this encoding, replace the characters in the string with their new variable-length prefix
codes
*/
// working
std::string HuffmanTree::compress(const std::string inputStr) {
    std::string tmp = inputStr;
    HuffmanTree::compressInput = tmp;

    // create a list of the frequency in which chars appear in the string using a map
    // working
    std::map<char, int> huffFreqMap;
    for(char ch : inputStr) {
        huffFreqMap[ch]++;
    }

    // Declare instance of priority queue
    // working
    HeapQueue<HuffmanNode*, HuffmanNode::Compare> hq;
    std::map<char, int>::iterator it;
    for(it = huffFreqMap.begin(); it != huffFreqMap.end(); ++it) {
        // std::cout << it->first << ':' << it->second << std::endl;
        HuffmanNode* hn = new HuffmanNode(it->first, it->second, nullptr, nullptr, nullptr);
        hq.insert(hn);
    }

    // Until there is one element left in the priority queue
    // working
    while(hq.size() != 1) {
        // std::cout << hq.min()->getCharacter() << ':' << hq.min()->getFrequency() << std::endl;

        // Remove two characters/frequencies pairs from the priority queue
        // Turn them into leaf nodes on a binary tree
        HuffmanNode* left = hq.min();
        hq.removeMin();
        HuffmanNode* right = hq.min();
        hq.removeMin();

        // Create an intermediate node to be their parent using the sum of the frequencies for
        // those children
        // working
        int summation = left->getFrequency() + right->getFrequency();
        // std::cout << "sum: " << summation << std::endl;
        HuffmanNode* parent = new HuffmanNode('\0', summation, nullptr, left, right);

        // Put that intermediate node back in the priority queue
        hq.insert(parent);
    }

        // The last pair in the priority queue is the root node of the tree
        // working
        HuffmanNode* root = hq.min();
        // std::cout << "root is: " << root->getCharacter() << root->getFrequency() << std::endl;

        // Using this new tree, encode the characters in the string using a map with their prefix code by
        // traversing the tree to find where the character’s leaf is. When traversal goes left, add a 0 to
        // the code, when it goes right, add a 1 to the code
        std::map<char, std::string> hnm;
        // working
        preOrder(root, "", hnm);
        postOrder(root);

        // working
        std::string returnStr = "";
        for(auto c : inputStr) {
                returnStr += hnm[c];
        }

        // working
        HuffmanTree::huffCodeString = returnStr;
        HuffmanTree::inStr = inputStr;
        HuffmanTree::huffCodeMap = hnm;

        //std::cout << "(compress) returnString: " << returnStr << std::endl;
        return returnStr;
};
/*
**************************************************************************************************
Serialize the tree using the above method. We do not need the frequency values to rebuild the
tree, just the characters on the leaves and where the branches are in the post order.
**************************************************************************************************
Tree serialization will organize the characters associated with the nodes using post order.
During the post order when you visit a node,
• if it the node is a leaf (external node) then you add a L plus the character to the serialize tree
string
• if it is a branch (internal node) then you add a B to the serialize tree string
*/
std::string HuffmanTree::serializeTree() const {
    // working
    //std::cout << "(serializedTree) returnString: " << huffSerialString << std::endl;
    return huffSerialString;
};

/*
***************************************************************************************************
Given a string created with the compress method and a serialized version of the tree, return the
decompressed original string
***************************************************************************************************
For decompression, two input arguments will be needed. The Huffman Code that was generated
by your compress method and the serialized tree string from your serializeTree method. Your
Huffman tree will have to be built by deserializing the tree string by using the leaves and
branches indicators. After you have your tree back, you can decompress the Huffman Code by
tracing the tree to figure out what variable length codes represent actual characters from the
original string.
*/
std::string HuffmanTree::decompress(const std::string inputCode, const std::string serializedTree) {
    decompressString = "";
    std::stack<HuffmanNode*> huffTree;
    HuffmanNode* left;
    HuffmanNode* right;

    HuffmanNode* hn = new HuffmanNode(serializedTree.at(1), 1, nullptr, nullptr, nullptr);
    huffTree.push(hn);
    for(unsigned int it = 1; it < serializedTree.size(); it++) {
        char el = serializedTree.at(it);
        /*
        *************************************************************************************
        Your Huffman tree will have to be built by deserializing the tree string by using the
        leaves and branches indicators.
        *************************************************************************************
        */
        if(el == 'B') {
            // added for constitution test to pass...
            if((serializedTree.at(it -1) == 'L') && (serializedTree.at(it -2) != 'L')) {
                continue;
            }    
            else {
                right = huffTree.top();
                huffTree.pop();
                left = huffTree.top();
                huffTree.pop();
                HuffmanNode* tmp = new HuffmanNode(el, 1, nullptr, left, right);
                huffTree.push(tmp);
            }
        }
        
        if((el == 'L') && (serializedTree.at(it -1) != 'L')) {
            HuffmanNode* hn = new HuffmanNode(serializedTree.at(it +1), 1, nullptr, nullptr, nullptr);
            huffTree.push(hn);
        }
    }

    /*
    **********************************************************************************************
    After you have your tree back, you can decompress the Huffman Code by
    tracing the tree to figure out what variable length codes represent actual characters from the
    original string.
    **********************************************************************************************
    */

    HuffmanNode* root;
    HuffmanNode* newRoot;

    postOrder(huffTree.top());
    root = huffTree.top();
    newRoot = huffTree.top();

    for(auto el : inputCode) {

        if(el == '1') {
            root = root->right;
            if(root->isLeaf()) {
                decompressString += root->getCharacter();
                root = newRoot;
            }
        }        

        if(el == '0') {
            root = root->left;
            if(root->isLeaf()) {
                decompressString += root->getCharacter();
                root = newRoot;
            }
        }
    }

    HuffmanNode* tmpTop = huffTree.top();
    clearTree(tmpTop);
    huffTree.pop();

    //std::cout << "(decompress) returnString: " << decompressString << std::endl;
    return decompressString;
};