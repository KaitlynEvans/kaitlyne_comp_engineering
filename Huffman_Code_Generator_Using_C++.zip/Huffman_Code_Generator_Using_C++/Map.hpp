#ifndef MAP_H
#define MAP_H

/*
The Constitution contains 4,543 words, including the signatures and has four sheets,
28-3/4 inches by 23-5/8 inches each. It contains 7,591 words including the 27 amendments
*/
const int TABLE_SIZE = 128;
class HashEntry {
    private:
        int key;
        int value; // or should this be a string?
    public:
        HashEntry(int k, int v) {
            key = k;
            value = v;
        };

        // ~HashEntry();

        int getKey() {
            return key;
        };
        int getValue() {
            return value;
        };   
};

class HashMap {
    private:
        HashEntry **table;
    public:
        HashMap() {
            table = new HashEntry*[TABLE_SIZE];
            for(int i = 0; i < TABLE_SIZE; ++i) {
                table[i] = NULL;
            }
        };

        ~HashMap() {
            for(int i = 0; i < TABLE_SIZE; ++i) {
                if(table[i] != NULL) {
                    delete table[i];
                }
            }
            delete[] table;
        };

        int get(int k) {
            int hash = (k % TABLE_SIZE);
            while(table[hash] != NULL && table[hash]->getKey() != k) {
                hash = (hash +1) % TABLE_SIZE; // linear probing
                if(table[hash] == NULL) {
                    return -1;
                }
                else {
                    return table[hash]->getValue();
                }
            }
        };
        void put(int k, int v) {
            int hash = (k % TABLE_SIZE);
            while(table[hash] != NULL && table[hash]->getKey() != k) {
                hash = (hash +1) % TABLE_SIZE;
                if(table[hash] != NULL) {
                    delete table[hash];
                    table[hash] = new HashEntry(k, v);
                }
            }
        };
};
#endif