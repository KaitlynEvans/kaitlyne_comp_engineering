
#include <stdio.h>
#include <math.h>
#include "mat_multi.h"

int main () {
  FILE *fp;

  // ----------------------------------------------------------
  // { {1,1, 1, 1}, {2, 2, 2, 2}, {3, 3, 3, 3}, {4, 4, 4, 4} };
  // input matrices A, B
  // ----------------------------------------------------------
  int A[4][4] = {1,1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4}; 
  int B[4][4] = {1,1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4};
  // ------------------
  // Results matrix, C
  // ------------------
  int C[4][4] = {};
  
  // multiplication function
  mat_multi(A, B, C);
	
	// Check the results of mat_multi() against the 
	// golden output.
  fp=fopen("out.dat","w");
  for (int i = 0; i < 4; i++) {
	// Save the results.
    for(int j = 0; j < 4; j++) {
		fprintf(fp,"C[%d]\n", C[i][j]);
	}
  }
  fclose(fp);
  
  printf ("Comparing against output data \n");
  if (system("diff -w out.dat out.gold")) {

	fprintf(stdout, "*******************************************\n");
	fprintf(stdout, "FAIL: Output DOES NOT match the golden output\n");
	fprintf(stdout, "*******************************************\n");
     return 1;
  } else {
	fprintf(stdout, "*******************************************\n");
	fprintf(stdout, "PASS: The output matches the golden output!\n");
	fprintf(stdout, "*******************************************\n");
     return 0;
  }
}
