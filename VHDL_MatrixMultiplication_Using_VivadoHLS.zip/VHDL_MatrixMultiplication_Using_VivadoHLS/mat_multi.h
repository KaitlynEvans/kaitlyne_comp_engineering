#ifndef MAT_MULTI_H_
#define MAT_MULIT_H_
#define N	4



void mat_multi (
  int A[N][N],
  int B[N][N],
  int C[N][N]
  );

#endif
