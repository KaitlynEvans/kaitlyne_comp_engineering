// Size of input arrays needs to be fixed
// in order for HLS to decides address bus 
// width.

void mat_multi(int A[4][4], int B[4][4], int C[4][4])
{
	  multi_loop_1:
	  for (int i = 0; i < 4; i++) {
		multi_loop_2: 
		for (int j = 0; j < 4; j++) {
			C[i][j] = 0;
			multi_loop_3:
			for(int k = 0; k < 4; k++) {
				C[i][j] += (A[i][k] * B[k][j]);
			}
		}
	}
}
